#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>


char SEM_NAME[]="milk";
  
int main()
{
    sem_t *semaphore;
    semaphore = sem_open(SEM_NAME,O_CREAT,0644,1);
    if(semaphore == SEM_FAILED)
    {
    	perror("unable to execute semaphore");
    	sem_close(semaphore);
    	exit(-1);
    }	
    
    int delivery = rand()%500+1;	
    // ftok to generate unique key
    key_t key = ftok("shmfile",65);
  
    // shmget returns an identifier in shmid
    int shmid = shmget(key,1024,0666|IPC_CREAT);
  
    // shmat to attach to shared memory
    int *product = (int*) shmat(shmid,(void*)0,0);
    

    sem_wait(semaphore);
    while(*product < delivery)
    {
    	delivery = delivery - 100;
    }
    if(delivery >= 0)
    {
    	*product = *product - delivery;
    	printf("Product delivered: %d\n",delivery);
    }
    else
    {	
    	printf("There is no enough product"); 	
    }
    sem_post(semaphore);
  
    
    printf("Product left: %d\n",*product);
    sem_close(semaphore);
    
    //detach from shared memory 
    shmdt(product);
    
    // destroy the shared memory
    //shmctl(shmid,IPC_RMID,NULL);
     
    return 0;
}
