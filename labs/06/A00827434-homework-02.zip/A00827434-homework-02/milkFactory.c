#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>


char SEM_NAME[]="milk";
  
int main()
{
    sem_t *semaphore;
    semaphore = sem_open(SEM_NAME,O_CREAT,0644,1);
    if(semaphore == SEM_FAILED)
    {
    	perror("unable to create sem");
    	sem_unlink(SEM_NAME);
    	exit(-1);
    }	
	
    int dailyProduction = 1000;
    	
    // ftok to generate unique key
    key_t key = ftok("shmfile",65);
  
    // shmget returns an identifier in shmid
    int shmid = shmget(key,1024,0666|IPC_CREAT);
  
    // shmat to attach to shared memory
    int *production = (int*) shmat(shmid,(void*)0,0);
    
         
    sem_wait(semaphore);
    *production = *production + dailyProduction;
    //to reset
    //*production = 1000;
    sem_post(semaphore);
  
    printf("Poduct quantity %d\n",*production);
    
    sem_close(semaphore);
    sem_unlink(SEM_NAME);  
    //detach from shared memory 
    shmdt(production);
  
    return 0;
}
