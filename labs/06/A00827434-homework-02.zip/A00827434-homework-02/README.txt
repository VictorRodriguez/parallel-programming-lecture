-This folder contains 6 separate files representing the milk factory and 5 sellers.
-Inter-proces communication is done with shared memory and semaphores,
-Regarding milkFactory.c:
	*The factory produces 1000 units of milk a day. It can get added to 	the previous day's leftover (if exist).
	*It is suposed to be the first process that controls the piece of 	shared memory every day.
-Regarding the seller.c (1 to 5):
	*They take a random delivery (from 1 to 500) each.
	*The priority of their deliveries is the order in which they made that delivery. 
